const money = n => '₹' + Number(n).toLocaleString('en-IN');
const getCart = () => JSON.parse(localStorage.getItem('smartzoneCart') || '[]');
const setCart = c => { localStorage.setItem('smartzoneCart', JSON.stringify(c)); updateCount(); };
function updateCount(){const el=document.getElementById('cartCount');if(el)el.textContent=getCart().reduce((s,x)=>s+x.qty,0);}
let allProducts=[], category='All';
async function loadProducts(){
 const params=new URLSearchParams({category,q:document.getElementById('searchInput')?.value||''});
 const res=await fetch('/api/products?'+params); allProducts=await res.json();
 const sort=document.getElementById('sortSelect')?.value;
 if(sort==='low')allProducts.sort((a,b)=>a.price-b.price);
 if(sort==='high')allProducts.sort((a,b)=>b.price-a.price);
 document.getElementById('resultCount').textContent=`${allProducts.length} phones found`;
 document.getElementById('productGrid').innerHTML=allProducts.map(p=>`<article class="product-card"><a href="product.html?id=${p.id}"><div class="product-image"><span class="tag">${p.tag||'Smart pick'}</span><img src="${p.image}" alt="${p.name}" onerror="this.style.display='none'"></div></a><div class="product-info"><span class="brand">${p.brand}</span><h3>${p.name}</h3><p>${p.description}</p><div class="price-row"><span class="price">${money(p.price)}</span><button class="add-btn" onclick="addToCart('${p.id}')">+ Add</button></div></div></article>`).join('') || '<div class="empty">No phones match your search.</div>';
}
async function addToCart(id){const p=allProducts.find(x=>x.id===id)||await (await fetch('/api/products/'+id)).json();let c=getCart();let item=c.find(x=>x.id===id);if(item)item.qty=Math.min(10,item.qty+1);else c.push({id,qty:1});setCart(c);alert(p.name+' added to cart!');}
document.addEventListener('DOMContentLoaded',()=>{updateCount();if(document.getElementById('productGrid')){loadProducts();document.getElementById('searchInput').addEventListener('input',loadProducts);document.getElementById('sortSelect').addEventListener('change',loadProducts);document.getElementById('filters').addEventListener('click',e=>{if(e.target.dataset.category){category=e.target.dataset.category;document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b===e.target));loadProducts();}});}document.getElementById('menuBtn')?.addEventListener('click',()=>document.querySelector('.topbar nav').classList.toggle('open'));});
