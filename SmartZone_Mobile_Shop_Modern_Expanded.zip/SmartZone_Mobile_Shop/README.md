# SmartZone Mobile Shop

A responsive full-stack mobile phone store demo built with HTML, CSS, JavaScript, Node.js and Express.

## Run on Windows
1. Install Node.js 18 or newer.
2. Open this folder in VS Code.
3. Open Terminal > New Terminal.
4. Run `npm install`
5. Run `npm start`
6. Open http://localhost:5000

You can also double-click `START_SMARTZONE.bat`.

## Demo features
- Product catalogue with search, category filters and sorting
- Product details and add-to-cart
- Shopping cart with quantity controls
- Checkout form and order confirmation
- Order lookup using order ID and phone number
- Admin dashboard to add products and view orders

## Demo admin
Email: admin@smartzone.test
Password: SmartZone@123

This is a learning/demo project. Orders are stored locally in `backend/data/store.json`.
No real payment gateway is connected; checkout creates a demo order without collecting card/UPI credentials.
