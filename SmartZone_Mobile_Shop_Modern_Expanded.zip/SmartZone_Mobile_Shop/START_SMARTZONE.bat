@echo off
title SmartZone Mobile Shop - Automatic Setup
cd /d "%~dp0"
echo ==========================================
echo       SMARTZONE MOBILE SHOP
echo ==========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Please install Node.js 18 or newer from https://nodejs.org/
  echo Then double-click this file again.
  pause
  exit /b 1
)
echo Checking and installing required packages...
if not exist node_modules (
  call npm install
  if errorlevel 1 (
    echo.
    echo Package installation failed. Check your internet connection.
    pause
    exit /b 1
  )
)
echo.
echo Opening SmartZone in your browser...
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:5000"
echo.
echo Starting the website. Keep this window open while using the site.
call npm start
pause
